

var username = document.querySelector("#advatar_name");

function profile_name(){
    username.innerText="Deadpool";
}



let vanish = document.querySelector(".individual1");
let vanish1 = document.querySelector(".individual")
let count = 2;
let countElement = document.querySelector(".banner_text_num");

function byeByePlus(){
    console.log("Hello")
    count ++;
    countElement.innerText = count +" connections";
    vanish.remove()
}

function byeByeMinus() {
    console.log("Hello")
    count --;
    countElement.innerText = count +" connections"; 
    vanish.remove()
}

function byeByePlus1(){
    console.log("Hello")
    count ++;
    countElement.innerText = count +" connections";
    vanish1.remove()
}


function byeByeMinus1() {
    console.log("Hello")
    count --;
    countElement.innerText = count +" connections"; 
    vanish1.remove()
}

