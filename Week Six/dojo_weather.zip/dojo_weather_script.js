



console.log("hello");


function state1(){
    alert("The Weather Is Decent")
}

function state2(){
    alert("It's Brick Out!")
}

function state3(){
    alert("Loading weather report.");

}



let poof = document.querySelector('.page_footer')

function acceptCookies() {
    poof.remove();
}


function c2f(temperature) {
    return Math.round(9 / 5 * temperature + 32);
}

function f2c(temperature) {
    return Math.round(5 / 9 * (temperature - 32));
}


    
function conversion(element) {
    console.log(element.value);
    for (var i=1; i<9; i++) {
        var temperatureSpan = document.querySelector("#temp" + i);
        var tempActual = parseInt(temperatureSpan.innerText);
        if(element.value == "°c") {
            temperatureSpan.innerText = f2c(tempActual);
        } else {
            temperatureSpan.innerText = c2f(tempActual);  
        }
    }
    // console.log(f2c(tempActual));
}
// console.log(c2f(tempActual));
