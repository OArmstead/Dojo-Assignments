
from crypt import methods
from flask import Flask, request, redirect, session, render_template 
from users import User

app = Flask(__name__)
app.secret_key = 'sonic'

@app.route("/")
def index():
    # AllUser = User.get_all()
    # print(AllUser)
    return redirect('/read')

@app.route('/read')
def read():
    AllUser = User.get_all()
    print(AllUser)
    return render_template('read.html', AllUser = User.get_all())
            
@app.route('/create')
def enter_info():
    # User.save(request.form)
    return render_template ('create.html')



@app.route('/new_info',methods=['POST'])
def create():
    print('it went through')
    print(request.form)
    User.save(request.form)
    return redirect('/read')
    
if __name__ == "__main__":
    app.run(debug=True)












