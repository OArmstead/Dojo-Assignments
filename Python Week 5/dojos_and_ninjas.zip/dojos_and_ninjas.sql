#SELECT * FROM dojos_and_ninjas_schema.dojos;

#Query: Create 3 more dojos
#INSERT INTO table_name (column_name1, column_name2) 
#VALUES('column1_value', 'column2_value');

#Query: Create 3 new dojos

#INSERT INTO dojos (name) values('Queens'),('Manhattan');

#Query: Delete the 3 dojos you just created

#SET SQL_SAFE_UPDATES = 0;
#DELETE FROM dojos WHERE name = 'Brooklyn';
#DELETE FROM dojos where name = 'Queens';
#DELETE FROM dojos WHERE name = 'Manhattan';

#Query: Create 3 more dojos
#INSERT INTO table_name (column_name1, column_name2) 
#VALUES('column1_value', 'column2_value');

#INSERT INTO dojos (name) VALUES('New York'),('Alabama'),('Texas')


#Query: Create 3 ninjas that belong to the first dojo
#INSERT INTO ninjas (first_name,last_name,age,dojo_id) Values('Pete','Rock','52','27'),('Large','Professor','49','27'),('9th','Wonder','47','27')

#Query: Create 3 ninjas that belong to the second dojo
#INSERT INTO ninjas (first_name,last_name,age,dojo_id) Values ('James','Bond','42',28),('Franklyn','Davis','27',28),('J','Dilla','32',28) 

#Query: Create 3 ninjas that belong to the third dojo
#INSERT INTO ninjas (first_name,last_name,age,dojo_id) Values ('Sean','Combs','52',29),('Dr','Dre','57',29),('Rick','Ruben','59',29) 

#Query: Retrieve all the ninjas from the first dojo
#SELECT * from ninjas where dojo_id = 27

#Query: Retrieve all the ninjas from the last dojo
#SELECT * from ninjas where dojo_id = 29


#Query: Retrieve the last ninja's dojo

-- SELECT * FROM orders 
-- JOIN customers ON customers.id = orders.customer_id;











