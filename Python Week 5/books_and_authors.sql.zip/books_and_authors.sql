#Query: Create 5 different authors: Jane Austen, 
#Emily Dickinson, Fyodor Dostoevsky, William Shakespeare, Lau Tzu

#INSERT INTO table_name (column_name1, column_name2) 
#VALUES('column1_value', 'column2_value');

#insert Into authors (name)
#Values('Emily Dickinson'), ('Fyodor Dostoevsky'), ('William Shakespeare'), ('Lau Tzu')

#Select * From authors

#Query: Create 5 books with the following names: 
# C Sharp, Java, Python, PHP, Ruby

#select * from books
#INSERT INTO books (title)
#values('C Sharp'), ('Java'), ('Python'), ('PHP'), ('Ruby')

#Select * from books

#Query: Change the name of the C Sharp book to C#

#UPDATE table_name SET column_name1 = 'some_value', 
#column_name2='another_value' WHERE condition(s)

 UPDATE books SET title = 'C#' wHERE ID = 1;
#Select * from books

#Query: Change the first name of the 4th author to Bill

#Update authors set name = 'Bill Shakespeare' where ID = 4;
#Select * from authors

# Have the first author favorite the first 2 books

#INSERT INTO table_name (column_name1, column_name2) 
#VALUES('column1_value', 'column2_value');

#Insert Into favorites (author_id, book_id)
#Values ('1' , '1');

#Insert Into favorites (author_id, book_id)
#Values ('1' , '2');

#select * from favorites

#Query: Have the second author favorite the first 3 books

#Insert Into favorites (author_id, book_id)
#Values ('2','1'),('2','2'),('2','3');

#Select * from favorites

#Query: Have the third author favorite all 5 books

#Insert Into favorites (author_id, book_id)
#Values ('3','1'),('3','2'),('3','3'),('3','4'),('3','5');

#Select * from favorites

#Query: Retrieve all the authors who favorited the 3rd book

#select * from favorites where book_id = 3;

#SELECT * FROM customers 
#JOIN addresses ON addresses.id = customers.address_id;

#Select * from books 
#join favorites on books.id = favorites.book_id
#Join authors on authors.id = favorites.author_id
#where book_id = 3

#Query: Remove the first author of the 3rd book's favorites
#Select * from authors
#select * from books
#Select * from favorites

#Delete from favorites where book_id = 3 and author_id = 2 
#select * from favorites

#Query: Have the 5th author favorite the 2nd book

#Insert Into favorites (author_id, book_id)
#Values (5,2)

#Query: Find all the books that the 2nd author favorited

#select * from favorites where author_id = 2

#Query: Find all the authors that favorited to the 5th book

#select * from favorites where book_id = 5

#Query: Find all the authors that favorited to the 2nd book
#select * from favorites where book_id = 2

#Query: Display all the book titles that the 2nd author favorited
# (Hint: Don't SELECT *)



SELECT * FROM books
JOIN favorites ON books.id = favorites.book_id
JOIN authors ON authors.id = favorites.author_id
WHERE books.id = 5;






