'''make_withdrawal(self, amount) - have this method decrease the user's balance 
by the amount specified

display_user_balance(self) - have this method print the user's name and 
account balance to the terminal eg. "User: Guido van Rossum, Balance: $150

BONUS: transfer_money(self, other_user, amount) - have this method decrease 
the user's balance by the amount and add that amount to other other_user's balance
'''

#Create a file with the User class, including the __init__ and make_deposit methods
class User:
    bank_name = 'Brooklyn National Bank'
    def __init__(self,name,):
        self.name = name
        self.amount = 0

    def make_deposit(self,amount):
        self.amount += amount

    def make_withdrawal(self,amount):
        self.amount -= amount

    def show_user_balance(self):
        # print(f"User: {self.name}, Balance: {self.amount}") #F string format (not working)
        print('{}: User: {}, Balance: {}'.format(self.bank_name,self.name, self.amount))

    def transfer_money(self,amount,user):
        self.amount -= amount
        user.amount += amount
        self.show_user_balance()
        user.show_user_balance()


brian = User ('Brian McNight')
brian.make_deposit(150)
brian.make_deposit(150)
brian.make_deposit(50)
brian.make_withdrawal(150)

steve = User ('Steve Nash')
steve.bank_name = ("New York City Bank")
steve.make_deposit(200)
steve.make_deposit(300)
steve.make_withdrawal(100.50)
steve.make_withdrawal(100)
steve.show_user_balance()

amare = User ("Amar'e Stoudamire")
amare.bank_name = ("Pheonix Bank of America")
amare.make_deposit(500)
amare.make_withdrawal(300)
amare.make_withdrawal(100.50)
amare.make_withdrawal(100)

brian.transfer_money(50, amare)