from flask import Flask, render_template  # Import Flask to allow us to create our app
app = Flask(__name__)    # Create a new instance of the Flask class called "app"

@app.route('/')          # The "@" decorator associates this route with the function immediately following
def index():
    return render_template('index.html', phrase = 'hello', times = 5)  # Return the string 'Hello World!' as a response

@app.route('/dojo')
def dojo():
    return "Dojo!"

@app.route('/say/<string:name>')
def hi(name):
    print(name)
    return ("Hi " + name +"!")

@app.route('/repeat/<int:num>/<string:word>')
def repeat(word,num):
    print(word)
    return (word + " ") * num

@app.route('/success')
def success():
    return "success"

@app.route('/ketchup')
def ketchup():
    return 'ketchup'

@app.route('/hello/<string:name>/<int:num>') 
def hello(num,name):
    print(name)
    return (" Hello, " + name  + "! ") * num 
    
    
if __name__=="__main__":
    app.run(debug=True)    # Run the app in debug mode.

