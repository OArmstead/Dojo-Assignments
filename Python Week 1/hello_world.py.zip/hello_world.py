# 1. TASK: print "Hello World"
print('Hello World')
    
#2. print "Hello Noelle!" with the name in a variable
name = 'Noelle'
print(name) +"!"

#print( 'Hello' , name  )	# with a comma
print( 'Hello',name,'!')

#print( "Hello " + name +"!" )	# with a +
print('Hello ' +  name)

 #3. print "Hello 42!" with the number in a variable
name = 42
print('Hello',name,'!')


#print(  )	# with a comma
print('Hello',42,'!')

print( 'Hello ' + str(42) + '!' )	# with a +	-- this one should give us an error!
# print(+)

# 4. print "I love to eat sushi and pizza." with the foods in variables
fave_food1 ='sushi'
fave_food2 = 'pizza'
# print('I love to eat '+ fave_food1 + ' and ' + fave_food2)

#print( your code here ) # with .format()
print('I love to eat {} and {}.'.format(fave_food1,fave_food2))

#print( your code here ) # with an f string
# #this give me a syntax error
#print( f"I love to eat {fave_food1} and {fave_food2}." ) copied from walkthrough. 
#only difference are the quotations



