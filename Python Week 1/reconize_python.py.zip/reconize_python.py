num1 = 42 # variable decloration, numbers
num2 = 2.3 #variable decloration, numbers
boolean = True # Boolean
string = 'Hello World' # String
pizza_toppings = ['Pepperoni', 'Sausage', 'Jalepenos', 
'Cheese', 'Olives'] # variable decloration, array
person = {'name': 'John', 'location': 'Salt Lake', 'age': 37, 'is_balding': False}
fruit = ('blueberry', 'strawberry', 'banana')
print(type(fruit)) # log statement
print(pizza_toppings[1]) # access value
pizza_toppings.append('Mushrooms') # chanage value
print(person['name']) # access value log statement
person['name'] = 'George' # access value, log statement
person['eye_color'] = 'blue' # access value, log statement
print(fruit[2]) = # access value, log statement

if num1 > 45: #if, log statement, else, log statemet
    print("It's greater")
else:
    print("It's lower")

if len(string) < 5: #if, log statement, else, log statement
    print("It's a short word!")
elif len(string) > 15: #else if
    print("It's a long word!")
else: #else
    print("Just right!")

for x in range(5): #for loop stops at 5 
    print(x) # log statement
for x in range(2,5): # loop starts at 2 ends at 5
    print(x) # log statement
for x in range(2,10,3): # loop starts at 2 ends at 10 in increments of 3
    print(x)
x = 0
while(x < 5): #while loop
    print(x)
    x += 1

pizza_toppings.pop() # delete last value
pizza_toppings.pop(1) # access value at this index then delete value

print(person) #log statement
person.pop('eye_color') # change  vale
print(person) # log statement

for topping in pizza_toppings: #for loop , start
    if topping == 'Pepperoni': #if conditional
        continue
    print('After 1st if statement')
    if topping == 'Olives': #if conditional
        break #stop

def print_hello_ten_times(): #log statement
    for num in range(10): #variable decloration
        print('Hello') #log statement

print_hello_ten_times() # print to console x 10

def print_hello_x_times(x):
    for num in range(x):
        print('Hello')

print_hello_x_times(4)

def print_hello_x_or_ten_times(x = 10):
    for num in range(x):
        print('Hello')

print_hello_x_or_ten_times() #print to console x 10
print_hello_x_or_ten_times(4) #print to console * 4


"""
Bonus section
"""

# print(num3)
# num3 = 72
# fruit[0] = 'cranberry' add to index 0
# print(person['favorite_team'])
# print(pizza_toppings[7]) print items from index 7
#   print(boolean) print statement 
# fruit.append('raspberry')
# fruit.pop(1) delete item at index 1