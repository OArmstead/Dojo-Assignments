from dojo_survey import app
from dojo_survey.controllers import survey_controller




if __name__=="__main__":  
    app.run(debug=True)