from dojo_survey import app
from dojo_survey.models.survey_model import Survey
from flask import render_template, redirect, session, request



@app.route('/')

def you_got_this():
    print('You had it in you all along')
    
    
    if 'jam' in session:
        print('Key in session')
    else:
        print('key not in session')
    # return redirect('/process')
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def create_survey():
    if not Survey.validate_survey(request.form):
        return redirect('/')
    Survey.save(request.form)
    return redirect('/result')

@app.route('/result')

def result():
    return render_template('result.html')

@app.route('/reset')
def reset():
    session.clear()
    return redirect('/')