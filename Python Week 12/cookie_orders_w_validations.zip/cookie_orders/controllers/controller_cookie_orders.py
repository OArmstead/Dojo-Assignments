from cookie_orders import app
from flask import render_template,redirect,request,session
from cookie_orders.models.model_cookie_order import Order
from cookie_orders.config.mysqlconnection import connectToMySQL
# from flask_bcrypt import Bcrypt
# bcrypt = Bcrypt(app)


@app.route('/')
def index():
    AllOrders = Order.get_all
    return render_template('cookies.html', AllOrders = Order.get_all())



# Create Order
@app.route('/new_order')
def new_order():
    return render_template('/new_order.html')

@app.route('/process_order',methods = ['POST'])
def process_order():
    if not Order.validate_order(request.form):
        return redirect('/new_order')
    data = {
            'name': request.form['name'],
            'cookie_type': request.form['cookie_type'],
            'number_of_boxes': request.form['number_of_boxes']
        }
    Order.save(data)
    return redirect('/')


#edit user

@app.route('/edit_cookies/<int:id>')
def edit(id):
    data ={
        'id':id
    }
    order = Order.get_one(data)
    return render_template('edit_cookies.html',order = order )


@app.route('/process', methods =['POST'])
def update():
    Order.update(request.form)
    return redirect('/')

