from cookie_orders.config.mysqlconnection import connectToMySQL
from flask import flash
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
from flask_bcrypt import Bcrypt

db='cookie_orders_schema'

class Order:
    def __init__(self,data):
        self.id = data['id']
        self.name = data['name']
        self.cookie_type = data['cookie_type']
        self.number_of_boxes = data['number_of_boxes']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
#prevent common attribute error by indenting @classmethod
    @classmethod
    def get_all(cls):
        query = 'SELECT * FROM orders'
        results = connectToMySQL(db).query_db(query)
        order = []
        for name in results:
            order.append(cls(name))
        return order

    @classmethod
    def get_one(cls,data):
        query ='SELECT * FROM orders WHERE id = %(id)s';
        result = connectToMySQL(db).query_db(query,data)
        return cls(result[0])

    @classmethod
    def update(cls,data):
        query = f'UPDATE orders SET name=%(name)s,cookie_type=%(cookie_type)s,number_of_boxes=%(number_of_boxes)s WHERE id= %(id)s;'
        return connectToMySQL(db).query_db(query,data)

    @staticmethod
    def validate_order(order):
        is_valid = True # we assume this is true
        if len(order['name']) < 3:
            flash("Name must be at least 3 characters.")
            is_valid = False
        if len(order['cookie_type']) < 3:
            flash("Cookie type must be at least 3 characters.")
            is_valid = False
        if int(len(order['number_of_boxes'])) < 1:
            flash("C'mon you're here to buy cookies.")
            is_valid = False
        return is_valid

    @classmethod
    def save(cls,data):
        query ='INSERT INTO orders (name, cookie_type, number_of_boxes) VALUES (%(name)s, %(cookie_type)s,%(number_of_boxes)s);'
        result=  connectToMySQL(db).query_db( query, data)
        return (result)

