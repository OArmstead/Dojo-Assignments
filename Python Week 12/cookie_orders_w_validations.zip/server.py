
from cookie_orders import app

from cookie_orders.controllers import controller_cookie_orders

if __name__=='__main__':
    app.run(debug=True)