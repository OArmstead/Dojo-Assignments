from flask import Flask, request, render_template, redirect, session
from users import User
app = Flask(__name__)




@app.route('/')
def index():
    return render_template('index.html')

@app.route('/create_user', methods =['POST'])
def create_user():
    User.create_user(request.form)
    return redirect('/read')

@app.route('/read')
def read():
    users = User.get_all()
    return render_template('/read.html', all_users = users)


@app.route('/edit_user/<int:user_id>')
def edit_user(user_id):
    data = {
        'id': user_id
    }
    user = User.get_one(data)
    return render_template('edit_user.html',user = user)

#update
@app.route('/update_user/<int:user_id>',methods =['POST'])
def update_user(user_id):
    data ={
        'id': user_id,
        'first_name': request.form['first_name'],
        'last_name': request.form['last_name'],
        'email': request.form['email']

    }
    User.update(data)
    return redirect('/read')

@app.route('/delete_user/<int:user_id>')
def delete_user(user_id):
    data ={
        'id': user_id
    }
    User.delete_user(data)
    return redirect('/read')

@app.route('/show_user/<int:user_id>')
def show_user(user_id):
    data={
    'id': user_id
    }
    user = User.get_one(data)
    return render_template('show_user.html', user = user)


if __name__=='__main__':
    app.run(debug=True)