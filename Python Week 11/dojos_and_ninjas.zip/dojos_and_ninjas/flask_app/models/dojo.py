# import the function that will return an instance of a connection
from flask_app.config.mysqlconnection import connectToMySQL
# model the class after the friend table from our database
from .ninjas import Ninja

class Dojo:
    def __init__(self , data):
        self.id = data['dojo_id']
        self.name = data['name']
        self.created_at = data['created_at']
        self.updated_at = data['uploaded_at']
        self.ninjas = []
    # Now we use class methods to query our database
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM dojos_and_ninjas_schema.dojos;"
        # make sure to call the connectToMySQL function with the schema you are targeting.
        results = connectToMySQL('dojos_and_ninjas_schema').query_db(query)
        print(results)
        dojos = []
        for d in results:
            dojos.append(cls(d))
        return dojos
    @classmethod
    def save(cls,data):
        query ='INSERT INTO dojos (name) VALUES (%(name)s);'
        result = connectToMySQL('dojos_and_ninjas_schema').query_db(query,data)
        return result


    @classmethod
    def get_one(cls,id):
        query ='Select * From dojos_and_ninjas_schema.dojos Where id =%(id)s;'
        result = connectToMySQL('dojos_and_ninjas_schema').query_db(query,{'dojo_id':id})
        return cls(result[0])

