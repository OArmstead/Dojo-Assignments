from flask import render_template, redirect, request
from flask_app import app
from flask_app.models.ninjas import Ninja


@app.route('/new_ninja')
def display():
    return render_template('new_ninja.html')

@app.route('/ninja_info', methods=['POST'])
def ninja_info():
    print('new ninja info')
    print(request.form)
    Ninja.save(request.form)
    return redirect('/new_ninja')