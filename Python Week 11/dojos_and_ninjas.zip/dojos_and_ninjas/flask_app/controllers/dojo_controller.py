from flask import render_template, redirect, request
from flask_app import app
from flask_app.models.dojo import Dojo


@app.route('/')
def index():

    return redirect('/main_page')



@app.route('/post',methods =['POST'])
def main_page_post():
    print('you got this O')
    print(request.form)
    Dojo.save(request.form)
    return redirect('/main_page')

@app.route('/main_page')
def main_page():
    return render_template('main_page.html', AllDojos = Dojo.get_all())

@app.route('/dojo_show/<int:id>')
def show_info(id):
    dojos=Dojo.get_one(id)
    data={
        'id':(id)
    }
    return render_template('dojo_show.html')
