from cookie_orders_w_validation import app
from cookie_orders_w_validation.models.models_order import Order
from flask import render_template, redirect,session,flash

@app.route('/')
def home():
    orders = Order.get_all()
    return render_template('index.html', all_orders = orders)




# Check both pages for validations do discussion questrions.