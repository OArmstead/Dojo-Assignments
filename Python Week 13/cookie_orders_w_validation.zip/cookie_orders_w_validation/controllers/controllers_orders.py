from cookie_orders_w_validation import app
from cookie_orders_w_validation.models.models_order import Order
from flask import render_template, redirect,session,flash,request



#Create order

@app.route('/new_orders',methods=['POST'])
def new_order():
    print(request.form)
    data ={
        'name': request.form['name'],
        'cookie_type': request.form['cookie_type'],
        'number_of_boxes':request.form['number_of_boxes']
    }
    if not Order.validate_order(request.form):
        return redirect('/new_order')
    Order.validate_order
    Order.save(data)

    return redirect('/')

@app.route('/new_order')
def a_new_order():
    Order.validate_order
    return render_template('/new_order.html')


#Update order

@app.route('/change_orders/<int:id>')
def change_order(id):
    data ={
        'id':id
    }
    orders = Order.get_one(data)
    # Order.validate_order
    return render_template('/change_order.html', orders = orders)

@app.route('/change_order', methods = ['POST'])
def update():
    # data ={
    #     # 'id': id,
    #     'id':request.form['id'],
    #     'name':request.form['name'],
    #     'cookie_type':request.form['cookie_type'],
    #     'number_of_boxes':request.form['number_of_boxes'],
    # }
    # print(data)
    if not Order.validate_order(request.form):
        return redirect(f"/change_orders/{request.form['id']}")
    Order.update(request.form)
    return redirect("/")

# @app.route('/make_changes/<int:id>')
# def make_changes(id):
#     data ={
#         'id':id
#     }
#     orders = Order.get_one(data)
#     return render_template('/change_order.html',orders = orders)