from flask import Flask, render_template,request,redirect,session
app = Flask(__name__)
app.secret_key= 'Maverick'

import random 
# value = random.randint(10,20)
# random.randint(10,20)

# location =	{
#     'cave': 'farm',
#     'house': 'house',
#     'cave': 'cave',
#     'casino':'casino'
# }

@app.route('/')     

def your_gold():
    print('Yeah you got this')

    return render_template('index.html')
    

    if 'total' not in session:
        print ('total not in session')

    # else:
    #     # (session['count'],int(random.randrange(1,10)))

    #     return redirect('/ppp')


@app.route('/process_money',methods=['POST'])

def pre_process_money():
    print('Omar')
    # print(request.form['location'])
    # session['total']= session['farm'] 

    # for x in location:
    #     print('the location is' + location)

    if request.form['location']=='farm':
        session['farm'] += random.randint(5,10)
        print(session['farm'])

    elif request.form['location']=='cave':
        session['cave']+= random.randint(5,10) 
        print(session['cave'])

    elif request.form['location']=='house':
        session['house']+= random.randint(2,5) 
        # print(session['house'])

    else: 
        request.form['location']=='casino'
        session['casino'] += random.randint(-50,50)
    # pass 
    session['total']=session['farm']+session['cave']+session['house']+session['casino']
    total = session['farm'] + session['cave']+session['cave']+session['house']+session['casino']
    print(total)
    # def total():
    # if 'cave' in session:
    #     print('cave in session')
    #     session['cave']+= random.randint(5,10)
    # if 'farm' in session:
    #     print('farm in session')
    #     session['farm']+= random.randint(10,20)
        # session['cave'] += random.randint(2,5)


    # if request.form['submit'] == 'submit':
        
    # session['cave'] =+ random.randint(100,200)
    return redirect('/')





# @app.route('/process_money')

# def process_money():


#     return render_template('index.html')



@app.route('/reset')     

def reset():
    print("let's clear it out")
    
    session['count'] = 0
    session['farm'] = 0
    session['cave'] = 0
    session['house'] = 0
    session['casino'] = 0
    session['total'] = 0

    return render_template('index.html')







if __name__=="__main__":  
    app.run(debug=True)