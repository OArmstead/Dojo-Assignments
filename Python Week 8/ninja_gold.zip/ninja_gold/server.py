from flask import Flask, render_template,request,redirect,session
app = Flask(__name__)
app.secret_key= 'Maverick'

import random


@app.route('/')

def your_gold():
    print('Yeah you got this')

    return render_template('index.html')


@app.route('/process_money',methods=['POST'])


def pre_process_money():
    session['count'] = 0
    session['farm'] = 0
    session['cave'] = 0
    session['house'] = 0
    session['casino'] = 0
    session['total'] = 0
    print('Omar')

    if request.form['location']=='farm':
        session['farm'] += random.randint(5,11)
        print(session['farm'])

    elif request.form['location']=='cave':
        session['cave']+= random.randint(5,11)
        print(session['cave'])

    elif request.form['location']=='house':
        session['house']+= random.randint(2,6)

    else:
        request.form['location']=='casino'
        session['casino'] += random.randint(-50,51)
    # pass
    session['total']=session['farm']+session['cave']+session['house']+session['casino']
    total = session['farm'] + session['cave']+session['cave']+session['house']+session['casino']
    print(total)
    return redirect('/')


@app.route('/reset')

def reset():
    print("let's clear it out")

    session['count'] = 0
    session['farm'] = 0
    session['cave'] = 0
    session['house'] = 0
    session['casino'] = 0
    session['total'] = 0

    return render_template('index.html')



if __name__=="__main__":
    app.run(debug=True)