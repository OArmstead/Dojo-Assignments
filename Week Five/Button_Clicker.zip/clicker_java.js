// function turnoff(btn){
//     Element.innerText="Log Out";
// }

console.log ("page loaded");

function pop_up(){
    alert("Ninja was liked");
}

function login(newName) {
    if(newName.innerText =='Login') {
        newName.innerText = 'Logout';
    } else {
        newName.innertext = 'Login';
    }
}

function gone(poof) {
    poof.remove();
}