# //localhost:5000 - have the template render the 
# number of times the client has visited this site
# localhost:5000/destroy_session - Clear the session. 
# Once cleared, redirect to the root.//




from flask import Flask, render_template, session, redirect
app = Flask(__name__)   
app.secret_key ='Omar 123'


@app.route('/')     

def hello_world():
    print('Yeah I did this')
    

    if 'count' not in session:
        return redirect('/destroy_session')

    else:
        session['count'] += 1

    return render_template('index.html')


@app.route('/destroy_session')     

def reset():
    print("let's clear it out")
    
    session['count'] = 0

    return render_template('index.html')

@app.route('/plus2')     

def plus2():
    print('Putting in work')
    
    session['count'] += 1

    return redirect('/')


if __name__=="__main__":  
    app.run(debug=True)  
